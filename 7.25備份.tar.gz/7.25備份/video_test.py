import numpy as np
import cv2
from keras.models import load_model
from keras.utils import np_utils
import PIL.ImageOps
from PIL import Image
from keras.preprocessing import image as image_utils

classes = ['clear', 'night', 'overcast', 'partly cloudy', 'rainy', 'snowy', 'undefind']


model = load_model("./WeatherPredictionFromImage-development/modelsCNN/size224/7.21_transfer/7.21_res_0.h5")
size = 224 
print ('load model')



videos = ['video/BSD2017City_F.mp4','video/BSD2017CityNight_F.mp4','video/FCWS2017CityRain_F.mp4',
          'video/FCWS2017Rain_F.mp4','video/vlc-record-2018-07-13-11h13m26s-fo-20180712_185834956.mp4-_F.mp4']


cap = cv2.VideoCapture(videos[3])
n = 0
buffer=[]
while(cap.isOpened()):
    try:
        ret, frame = cap.read()
        
        img = cv2.resize(frame, (size, size), interpolation=cv2.INTER_CUBIC)
        
#        img = np.array(img , dtype=np.uint8)
#        img = Image.fromarray(img, 'RGB')
#        img = PIL.ImageOps.invert(img)  # inverts it
#        img = image_utils.img_to_array(img)  # converts it to array
        
        img = img / 255.0
        buffer.append(img)
        # Take Mode with 20 batches
        if n % 20 == 0:
            buffer = np.reshape(buffer,(len(buffer),size,size,3))
            ans = model.predict(buffer, verbose=0)
            ans = np.sum( ans ,axis=0)
            

            if np.argmax(ans)!=6:
                ans = np.argmax(ans)
            else : 
                ans[6]=0
                ans = np.argmax(ans)
            buffer=[]
        print (classes[ans])
        
        cv2.putText(frame, classes[ans], (10, 500), cv2.FONT_HERSHEY_TRIPLEX, 5, (0, 255, 255), 1, cv2.LINE_AA)
        cv2.imshow('frame',frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        
        cv2.waitKey(10)
    except:
        pass
    n+=1
cap.release()
cv2.destroyAllWindows()




# -------------------------------------------- two class ------------------------------------------------------------






classes = [ 'sunny','overcast',  'rainy']
day = ['daytime' , 'night']

model = load_model("/home/baker/Desktop/WeatherPredictionFromImage-development/modelsCNN/size224/7.21_Dual_CNN/dual_tune.h5")
size = 224
print ('load model')

videos = ['video/BSD2017City_F.mp4','video/BSD2017CityNight_F.mp4','video/FCWS2017CityRain_F.mp4',
          'video/FCWS2017Rain_F.mp4','video/vlc-record-2018-07-13-11h13m26s-fo-20180712_185834956.mp4-_F.mp4']

cap = cv2.VideoCapture(videos[1])
n = 0
buffer=[]
while(cap.isOpened()):
    try:
        ret, frame = cap.read()
        
        img = cv2.resize(frame, (size, size), interpolation=cv2.INTER_CUBIC)
        
#        img = np.array(img , dtype=np.uint8)
#        img = Image.fromarray(img, 'RGB')
#        img = PIL.ImageOps.invert(img)  # inverts it
#        img = image_utils.img_to_array(img)  # converts it to array
        
        img = img / 255.0
        buffer.append(img)
        # Take Mode with 20 batches
        if n % 5 == 0:
            buffer = np.reshape(buffer,(len(buffer),size,size,3))
            ans = model.predict(buffer, verbose=0)

            ans1 = np.sum( ans[0] ,axis=0)
            ans2 = np.sum( ans[1] ,axis=0)

            ans1 = np.argmax(ans1)
            ans2 = np.argmax(ans2)
            
            buffer=[]
            
        
        cv2.putText(frame, classes[ans1], (10, 300), cv2.FONT_HERSHEY_TRIPLEX, 5, (0, 255, 255), 1, cv2.LINE_AA)
        cv2.putText(frame, day    [ans2], (10, 500), cv2.FONT_HERSHEY_TRIPLEX, 5, (0, 255, 255), 1, cv2.LINE_AA)
        cv2.imshow('frame',frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        
        cv2.waitKey(10)
    except:
        pass
    n+=1
cap.release()
cv2.destroyAllWindows()



# -------------------------------------------- two class4 ------------------------------------------------------------


classes = ['clear', 'sunny','overcast',  'rainy']
day = ['daytime' , 'night']

model = load_model("/home/baker/Desktop/WeatherPredictionFromImage-development/modelsCNN/size224/7.24_Dual_CNN/dual4_2.h5")
size = 224
print ('load model')

videos = ['video/BSD2017City_F.mp4','video/BSD2017CityNight_F.mp4','video/FCWS2017CityRain_F.mp4',
          'video/FCWS2017Rain_F.mp4','video/vlc-record-2018-07-13-11h13m26s-fo-20180712_185834956.mp4-_F.mp4']



def test(i):
    cap = cv2.VideoCapture(videos[i])
    n = 0
    buffer=[]
    flag=False
    while(cap.isOpened()):
        try:
            ret, frame = cap.read()
            
            img = cv2.resize(frame, (size, size), interpolation=cv2.INTER_CUBIC)
    
            img = img / 255.0
            buffer.append(img)
            # Take Mode with 20 batches
            if n % 5 == 0:
                buffer = np.reshape(buffer,(len(buffer),size,size,3))
                ans = model.predict(buffer, verbose=0)
    
                ans1 = np.sum( ans[0] ,axis=0)
                ans2 = np.sum( ans[1] ,axis=0)
                if np.argmax(ans1) == 3 :
                    print (ans1)
                    #cv2.imwrite('/home/baker/Desktop/BDD100K/1video_night/'+str(n)+'.png',img*255)
                    flag = True
                else :
                    flag = False
                ans1[3] = 0
                ans1 = np.argmax(ans1)
                ans2 = np.argmax(ans2)
                
                buffer=[]
                
            cv2.putText(frame, classes[ans1], (10, 300), cv2.FONT_HERSHEY_TRIPLEX, 4, (0, 255, 255), 3, cv2.LINE_AA)
            cv2.putText(frame, day    [ans2], (10, 500), cv2.FONT_HERSHEY_TRIPLEX, 4, (0, 255, 255), 3, cv2.LINE_AA)
            if flag == True:
                cv2.putText(frame, 'rainy' , (700, 500), cv2.FONT_HERSHEY_TRIPLEX, 2, (0, 0, 255), 5, cv2.LINE_AA)
            
            cv2.imshow('frame',frame)
            cv2.moveWindow("frame", 40,30)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
            cv2.waitKey(10)
        except:
            pass
        n+=1
    cap.release()
    cv2.destroyAllWindows()

test(0)




#catch video
size=500
cap = cv2.VideoCapture(videos[1])
n = 0
buffer=[]
while(cap.isOpened()):
    try:
        ret, frame = cap.read()
        n+=1
        img = cv2.resize(frame, (size, size), interpolation=cv2.INTER_CUBIC)
            
        if (n%11) == 0:
            print (n)
            cv2.imwrite('/home/baker/Desktop/BDD100K/1video_night/'+str(n)+'.png',img)
            
        
        cv2.imshow('frame',frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        
        #cv2.waitKey(10)
    except:
        pass
    n+=1
cap.release()
cv2.destroyAllWindows()




def test(i):
    cap = cv2.VideoCapture(videos[i])
    n = 0
    buffer=[]
    flag=False
    while(cap.isOpened()):
        try:
            ret, frame = cap.read()
            
            img = cv2.resize(frame, (size, size), interpolation=cv2.INTER_CUBIC)
    
            img = img / 255.0
            buffer.append(img)
            # Take Mode with 20 batches
            if n % 1 == 0:
                buffer = np.reshape(buffer,(len(buffer),size,size,3))
                ans = model.predict(buffer, verbose=0)
    
                ans1 = np.sum( ans[0] ,axis=0)
                ans2 = np.sum( ans[1] ,axis=0)
                if np.argmax(ans1) == 3 :
                    print (ans1)
                    #cv2.imwrite('/home/baker/Desktop/BDD100K/1video_night/'+str(n)+'.png',img*255)
                    flag = True
                else :
                    flag = False
                ans1[3] = 0
                ans1 = np.argmax(ans1)
                ans2 = np.argmax(ans2)
                
                buffer=[]
                
            cv2.putText(frame, classes[ans1], (10, 300), cv2.FONT_HERSHEY_TRIPLEX, 4, (0, 255, 255), 3, cv2.LINE_AA)
            cv2.putText(frame, day    [ans2], (10, 500), cv2.FONT_HERSHEY_TRIPLEX, 4, (0, 255, 255), 3, cv2.LINE_AA)
            if flag == True:
                cv2.putText(frame, 'rainy' , (700, 500), cv2.FONT_HERSHEY_TRIPLEX, 2, (0, 0, 255), 5, cv2.LINE_AA)
            
            cv2.imshow('frame',frame)
            cv2.moveWindow("frame", 40,30)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
            cv2.waitKey(10)
        except:
            pass
        n+=1
    cap.release()
    cv2.destroyAllWindows()










