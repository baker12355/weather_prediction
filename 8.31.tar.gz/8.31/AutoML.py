import numpy as np 
from keras.utils import np_utils

classes = { "clear":0, "foggy":1, "overcast":2, "partly cloudy":3,
           "rainy":4, "snowy":5, "undefined":6 }

def preprocess_input(x):
    x = np.divide(x, 255.0)
    x = np.subtract(x, 0.5)
    x = np.multiply(x, 2.0)
    return x

def load_train ():
    print ('loading data..')    
    # ---------------------------------------------------------------------------
    

    size = 224
    dest = '/home/baker/Desktop/BDD100K/digitalize/'+str(size)+'/train'
    
    # -----------------load labels - day or night -vertical concat them &--------
    
    d_clear_label     = np.load(dest + "/clear/"  + "/clear10K_l.npy" ) 
    d_clear_label     = d_clear_label[:5000]
    d_cloudy_label    = np.load(dest + "/partly cloudy/"  + "/train_label.npy" ) 
    d_overcast_label  = np.load(dest + "/overcast/"   + "/train_label.npy" )    
    d_overcast_label  = d_overcast_label[:5000]
    d_rainy_label     = np.load(dest + "/rainy/"  + "/train_label.npy" ) 
    
    t_clear_label     = np.array ([0 for i in range(len(d_clear_label))])
    t_cloudy_label    = np.array ([1 for i in range(len(d_cloudy_label))])
    t_overcast_label  = np.array ([2 for i in range(len(d_overcast_label))])
    t_rainy_label     = np.array ([3 for i in range(len(d_rainy_label))])


    train_label   = np.hstack([t_clear_label,t_cloudy_label,t_overcast_label,t_rainy_label])
    train_label_d = np.hstack([d_clear_label,d_cloudy_label,d_overcast_label,d_rainy_label])
    

    print ('label done.')
    
    # --------------------load every weather in a balance size------------------

    train_clear       = np.load (dest + "/clear/" + "/clear10K_d.npy" )          # 5000 
    train_clear       = train_clear[:5000]
    train_clear       = preprocess_input(train_clear)
    #train_clear       = train_clear/255.0
    print ('clear load.')
    
    train_cloudy      = np.load (dest + "/partly cloudy/"  + "/train_data.npy" ) # 4886
    train_cloudy       = preprocess_input(train_cloudy)
    #train_cloudy      = train_cloudy/255.0
    print ('cloudy load.')
    
    train_overcast    = np.load (dest + "/overcast/"     + "/train_data.npy" )   # 8784
    train_overcast    = train_overcast[:5000]
    train_overcast    = preprocess_input(train_overcast)
    #train_overcast    = train_overcast/255.0
    print ('overcast load.')
    
    train_rainy       = np.load (dest + "/rainy/"      + "/train_data.npy" )     # 5070
    train_rainy       = preprocess_input(train_rainy)
    #train_rainy       = train_rainy/255.0
    print ('rainy load.')

    train_data    = np.vstack([train_clear,train_cloudy,train_overcast,train_rainy])
    
    print ('All done.')  
    return train_data,train_label,train_label_d



# --------------------------------load data------------------------------------

train_data , train_label , train_label_d = load_train()

from sklearn.model_selection import train_test_split

split = train_test_split(train_data, train_label, train_label_d,test_size=0.2, random_state=42)
(trainX, testX, trainWY, testWY,	trainDY, testDY) = split
del train_data,train_label,train_label_d

# ----------------------------------------------------------------------------

a = trainX[3:6]
b = trainWY[3:6]
at= testX [3:6]
bt= testWY[3:6]

import autokeras as ak

clf = ak.ImageClassifier(verbose=True)

clf.fit(trainX, trainWY , time_limit= 60)

clf.final_fit(trainX, trainWY, testX, testWY, retrain=True)
results = clf.predict(testX)




clf.fit(a,b)


from keras.datasets import mnist
from autokeras.classifier import ImageClassifier


(x_train, y_train), (x_test, y_test) = mnist.load_data()
x_train = x_train.reshape(x_train.shape + (1,))
x_test = x_test.reshape(x_test.shape + (1,))

clf = ImageClassifier(verbose=True)
clf.fit(x_train, y_train, time_limit=12 * 60 * 60)
clf.final_fit(x_train, y_train, x_test, y_test, retrain=True)
y = clf.evaluate(x_test, y_test)
print(y)


















