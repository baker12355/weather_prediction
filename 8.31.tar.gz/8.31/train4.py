import numpy as np 
from keras.utils import np_utils


classes = { "clear":0, "foggy":1, "overcast":2, "partly cloudy":3,
           "rainy":4, "snowy":5, "undefined":6 }


def preprocess_input(x):
    x = np.divide(x, 255.0)
    x = np.subtract(x, 0.5)
    x = np.multiply(x, 2.0)
    return x


def load_train ():
    print ('loading data..')    
    # ---------------------------------------------------------------------------
    
    num_classes = 4
    num_classes2= 2
    size = 224
    dest = '/home/baker/Desktop/BDD100K/digitalize/'+str(size)+'/train'
    
    # -----------------load labels - day or night -vertical concat them &--------
    
    d_clear_label     = np.load(dest + "/clear/"  + "/clear10K_l.npy" ) 
    d_clear_label     = d_clear_label[:5000]
    d_cloudy_label    = np.load(dest + "/partly cloudy/"  + "/train_label.npy" ) 
    d_overcast_label  = np.load(dest + "/overcast/"   + "/train_label.npy" )    
    d_overcast_label  = d_overcast_label[:5000]
    d_rainy_label     = np.load(dest + "/rainy/"  + "/train_label.npy" ) 
    
    t_clear_label     = np.array ([0 for i in range(len(d_clear_label))])
    t_cloudy_label    = np.array ([1 for i in range(len(d_cloudy_label))])
    t_overcast_label  = np.array ([2 for i in range(len(d_overcast_label))])
    t_rainy_label     = np.array ([3 for i in range(len(d_rainy_label))])


    train_label   = np.hstack([t_clear_label,t_cloudy_label,t_overcast_label,t_rainy_label])
    train_label_d = np.hstack([d_clear_label,d_cloudy_label,d_overcast_label,d_rainy_label])
    
    train_label   = np_utils.to_categorical(train_label, num_classes)
    train_label_d = np_utils.to_categorical(train_label_d, num_classes2)
    print ('label done.')
    
    # --------------------load every weather in a balance size------------------

    train_clear       = np.load (dest + "/clear/" + "/clear10K_d.npy" )          # 5000 
    train_clear       = train_clear[:5000]
    train_clear       = preprocess_input(train_clear)
    #train_clear       = train_clear/255.0
    print ('clear load.')
    
    train_cloudy      = np.load (dest + "/partly cloudy/"  + "/train_data.npy" ) # 4886
    train_cloudy       = preprocess_input(train_cloudy)
    #train_cloudy      = train_cloudy/255.0
    print ('cloudy load.')
    
    train_overcast    = np.load (dest + "/overcast/"     + "/train_data.npy" )   # 8784
    train_overcast    = train_overcast[:5000]
    train_overcast    = preprocess_input(train_overcast)
    #train_overcast    = train_overcast/255.0
    print ('overcast load.')
    
    train_rainy       = np.load (dest + "/rainy/"      + "/train_data.npy" )     # 5070
    train_rainy       = preprocess_input(train_rainy)
    #train_rainy       = train_rainy/255.0
    print ('rainy load.')

    train_data    = np.vstack([train_clear,train_cloudy,train_overcast,train_rainy])
    
    print ('All done.')  
    return train_data,train_label,train_label_d



# --------------------------------load data------------------------------------


train_data , train_label , train_label_d = load_train()


# --------------------------------build model ---------------------------------
from keras.initializers import RandomNormal
from keras.models import Model
from keras.layers.normalization import BatchNormalization
from keras.layers.convolutional import Conv2D
from keras.layers.convolutional import MaxPooling2D
from keras.layers.core import Activation
from keras.layers.core import Dropout
from keras.layers.core import Dense
from keras.layers import Flatten
from keras.layers import Input
from keras.callbacks import ModelCheckpoint , EarlyStopping
from keras.optimizers import Adam
from sklearn.model_selection import train_test_split

split = train_test_split(train_data, train_label, train_label_d,test_size=0.2, random_state=42)
(trainX, testX, trainWY, testWY,	trainDY, testDY) = split
del train_data,train_label,train_label_d

# initialize our FashionNet multi-output network

EPOCHS = 80
INIT_LR = 1e-1

inputShape = (224, 224, 3)
chanDim = -1
numCategories = 4


inputs = Input(shape=inputShape)
x = Conv2D(256, (2, 2), padding="same",name='W01',
           kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
           bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(inputs)
x = BatchNormalization(axis=chanDim,name='W03')(x)
x = Activation("relu",name='W02')(x)
x = MaxPooling2D(pool_size=(5, 5),name='W04')(x)
x = Dropout(0.25,name='W05')(x)

# CONV => RELU) * 2 => POOL
x = Conv2D(128, (3, 3), padding="same",name='W06',
             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
x = BatchNormalization(axis=chanDim,name='W08')(x)
x = Activation("relu",name='W07')(x)
x = Conv2D(128, (3, 3), padding="same",name='W09',
           kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
           bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
x = BatchNormalization(axis=chanDim,name='W11')(x)
x = Activation("relu",name='W10')(x)
x = MaxPooling2D(pool_size=(5, 5),name='W12')(x)
x = Dropout(0.25,name='W13')(x)

# CONV => RELU) * 2 => POOL
x = Conv2D(64, (3, 3), padding="same",name='W14',
             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
x = Activation("relu",name='W15')(x)
x = BatchNormalization(axis=chanDim,name='W16')(x)
x = Conv2D(64, (3, 3), padding="same",name='W17',
           kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
           bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
x = Activation("relu",name='W18')(x)
x = BatchNormalization(axis=chanDim,name='W19')(x)
x = MaxPooling2D(pool_size=(5, 5),name='W20')(x)
x = Dropout(0.25,name='W21')(x)

# define a branch of output layers for the number of different
# clothing categories (i.e., shirts, jeans, dresses, etc.)
x = Flatten(name='W30')(x)
x = Dense(50,name='W31')(x)
x = Dense(50,name='T31')(x)
x = BatchNormalization(name='W33')(x)
x = Activation("relu",name='W32')(x)
x = Dropout(0.5,name='W34')(x)
x = Dense(numCategories,name='W35')(x)
x = Activation('softmax', name="category_output")(x)

model = Model(inputs=inputs, outputs= x, name="fashionnet")
model.summary()

losses = "categorical_crossentropy"

# initialize the optimizer and compile the model
print("[INFO] compiling model...")
opt = Adam(lr=INIT_LR, decay=INIT_LR / EPOCHS)
model.compile(optimizer='adam', loss=losses,metrics=["accuracy"])


earlystop = EarlyStopping(monitor='val_loss', min_delta=0, patience=10, verbose=0, mode='auto')

checkpointer = ModelCheckpoint(filepath='modelsCNN/size224/8.1_CNN/CNN4_2.h5', verbose=1, save_best_only=True)


H = model.fit( trainX, trainWY,
	validation_data=[testX, testWY],
    callbacks = [ checkpointer ] ,   
    shuffle=True,
	epochs=80,
	verbose=1,
    batch_size=32,
    )





#for i in range(10,100):
#    earlystop = EarlyStopping(monitor='val_loss', min_delta=0, patience=10, verbose=0, mode='auto')
#    
#    checkpointer = ModelCheckpoint(filepath='modelsCNN/size224/8.1_CNN/CNN4_'+str(i)+'.h5', verbose=1, save_best_only=True)
#    
#    H = model.fit( trainX, trainWY,
#    	validation_data=[testX, testWY],
#        callbacks = [ checkpointer ,earlystop] ,   
#        shuffle=True,
#    	epochs=50,
#    	verbose=1,
#        batch_size=32,
#        )













