import numpy as np 
from keras.utils import np_utils
from sklearn.model_selection import train_test_split

classes = { "clear":0, "foggy":1, "overcast":2, "partly cloudy":3,
           "rainy":4, "snowy":5, "undefined":6 }

def preprocess_input(x):
    x = np.divide(x, 255.0)
    x = np.subtract(x, 0.5)
    x = np.multiply(x, 2.0)
    return x

def load_train ():
    print ('loading data..')    
    # ---------------------------------------------------------------------------
    
    num_classes2= 2
    size = 224
    dest = '/home/baker/Desktop/BDD100K/digitalize/'+str(size)+'/train'
    
    # -----------------load labels - day or night -vertical concat them &--------
    
    d_clear_label     = np.load(dest + "/clear/"  + "/clear10K_l.npy" ) 
    d_clear_label     = d_clear_label[:10000]
    d_cloudy_label    = np.load(dest + "/partly cloudy/"  + "/train_label.npy" ) 
    d_overcast_label  = np.load(dest + "/overcast/"   + "/train_label.npy" )    
    d_overcast_label  = d_overcast_label[:5000]
    d_rainy_label     = np.load(dest + "/rainy/"  + "/train_label.npy" ) 
    d_snowy_label     = np.load(dest + "/snowy/"  + "/train_label.npy" ) 

    train_label_d = np.hstack([d_clear_label,d_cloudy_label,d_overcast_label,
                               d_rainy_label,d_snowy_label])

    train_label_d = np_utils.to_categorical(train_label_d, num_classes2)
    print ('label done.')
    
    # --------------------load every weather in a balance size------------------

    train_clear       = np.load (dest + "/clear/" + "/clear10K_d.npy" )          # 5000 
    train_clear       = train_clear[:10000]
    train_clear       = preprocess_input(train_clear)
    #train_clear       = train_clear/255.0
    print ('clear load.')
    
    train_cloudy      = np.load (dest + "/partly cloudy/"  + "/train_data.npy" ) # 4886
    train_cloudy       = preprocess_input(train_cloudy)
    #train_cloudy      = train_cloudy/255.0
    print ('cloudy load.')
    
    train_overcast    = np.load (dest + "/overcast/"     + "/train_data.npy" )   # 8784
    train_overcast    = train_overcast[:5000]
    train_overcast    = preprocess_input(train_overcast)
    #train_overcast    = train_overcast/255.0
    print ('overcast load.')
    
    train_rainy       = np.load (dest + "/rainy/"      + "/train_data.npy" )     # 5070
    train_rainy       = preprocess_input(train_rainy)
    #train_rainy       = train_rainy/255.0
    print ('rainy load.')
    
    train_snowy       = np.load (dest + "/snowy/"      + "/train_data.npy" )     # 
    train_snowy       = preprocess_input(train_snowy)
    #train_rainy       = train_rainy/255.0
    print ('snowy load.')
    
    train_data    = np.vstack([train_clear,train_cloudy,train_overcast,train_rainy,train_snowy])
    
    print ('All done.')  
    return train_data, train_label_d

# --------------------------------load data------------------------------------

train_data , train_label_d = load_train()

split = train_test_split(train_data, train_label_d,test_size=0.2, random_state=42)
(trainX, testX, trainDY, testDY) = split
del train_data,train_label_d


# -----------------------------------------------------------------------------

from keras.models import Sequential
from keras.layers.core import Activation
from keras.layers.core import Dropout
from keras.layers.core import Dense
from keras.layers.convolutional import Conv2D
from keras.layers.convolutional import MaxPooling2D
from keras.layers.normalization import BatchNormalization
from keras.layers import Flatten
from keras.layers import Input
from keras.models import Model
from keras.callbacks import ModelCheckpoint 


inputs = Input(shape=(224,224,3))
# CONV => RELU => POOL
x = Conv2D(16, (3, 3), padding="same")(inputs)
x = BatchNormalization(axis=-1)(x)
x = Activation("relu")(x)
x = MaxPooling2D(pool_size=(3, 3))(x)
x = Dropout(0.25)(x)
 
# CONV => RELU => POOL
x = Conv2D(16, (3, 3), padding="same")(x)
x = BatchNormalization(axis=-1)(x)
x = Activation("relu")(x)
x = MaxPooling2D(pool_size=(2, 2))(x)
x = Dropout(0.25)(x)

x = Flatten()(x)
x = Dense(10)(x)
x = BatchNormalization()(x)
x = Activation("relu")(x)
x = Dropout(0.5)(x)
x = Dense(2)(x)
output = Activation('softmax', name="output")(x)

model = Model(inputs=inputs,outputs= output )


lossWeights = { 0:0.5,
                1:1.0}
 
# initialize the optimizer and compile the model
print("[INFO] compiling model...")
model.compile(optimizer = 'adam',
              loss = 'categorical_crossentropy',
              metrics = ["accuracy"])

checkpointer = ModelCheckpoint(filepath='../DN_0.h5', verbose=1, save_best_only=True)


H = model.fit(trainX, trainDY,
              validation_data=[testX, testDY],
              callbacks = [checkpointer] ,
              epochs=500,
              verbose=1,
              batch_size=100,
              class_weight=lossWeights)



















