import numpy as np
import cv2
from keras.models import load_model
from keras.utils import np_utils
import PIL.ImageOps
from PIL import Image
from keras.preprocessing import image as image_utils
import time
from collections import deque

import matplotlib.pyplot as plt  

def preprocess_input(x):
    x = np.divide(x, 255.0)
    x = np.subtract(x, 0.5)
    x = np.multiply(x, 2.0)
    return x

# ------------------------------------- two class4 -------------------------------

classes = ['clear', 'sunny','cloudy',  'rainy']
day = ['D' , 'N']
color = [(68,240,68),(68,68,240),(240,68,68),(118,32,255)]
dest = 'modelsCNN/size224/'
model = load_model(dest + "8.10_CNN/NORMAL_35.h5")

size = 224
print ('load model')

des = ''
videos = [des + '../video/BSD2017City_F.mp4',
          des + '../video/BSD2017CityNight_F.mp4',
          des + '../video/FCWS2017CityRain_F.mp4',
          des + '../video/FCWS2017Rain_F.mp4',
          des + '../video/rainy/videoplayback.mp4',
          des + '../video/rainy/videoplayback (1).mp4',
          des + '../video/rainy/output.mp4',
          des + '../video/rainy/videoplayback (3).mp4',
          des + '../video/sunny1.mp4',
          des + '../video/sunny2.mp4',
          des + '../video/tunnel1.mp4',
          des + '../video/tunnel2.mp4',
          des + '../video/GTA/1.mp4',
          des + '../video/GTA/2.mp4',
          des + '../video/GTA/3.mp4',
          des + '../video/GTA/4.mp4',
          des + '../video/GTA/5.mp4',
          '/home/baker/Desktop/final_photo/demo/ori.mp4' ]

def test(i):
    cap = cv2.VideoCapture(videos[i])
    n = 1
    buffer,bufferr,buffer1 = [],[],[]
    fps,fpss,flag,t0,t1,t2,t3,d0,d1,ans1,ans2 = 0,0,0,0,0,0,0,0,0,0,0
    while(cap.isOpened()):
        try:
            start = time.time()
            ret, frame = cap.read()
            
            frame = cv2.resize(frame, (1480, 840), interpolation=cv2.INTER_CUBIC)

            if n % 1 == 0 :
                # img preprocessing
                img = cv2.resize(frame, (size, size), interpolation=cv2.INTER_CUBIC)
                img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
                img = preprocess_input(img)
                img = np.reshape(img, (1, size, size, 3))
                ans = model.predict(img , verbose=0)

                # use buffer to taking average , more stable
                buffer.append(ans[0])
                bufferr.append(ans[1])

                # find max
                ans1 = np.sum(buffer, axis=0)
                ans2 = np.sum(bufferr, axis=0)

                t0   = ans1[0][0]*100/len(buffer)
                t1   = ans1[0][1]*100/len(buffer)
                t2   = ans1[0][2]*100/len(buffer)
                t3   = ans1[0][3]*100/len(buffer)
                d0   = ans2[0][0]*100/len(buffer)
                d1   = ans2[0][1]*100/len(buffer)
                
                flag = ans1[0][3]*100//len(buffer)

                # final weather answer
                ans1 = np.argmax(ans1)
                ans2 = np.argmax(ans2)
                
            # take only last 20
            if len(buffer)>49:
                buffer = buffer[1:50]
                bufferr = bufferr[1:50]
                    
            if len(buffer1)>99: 
                buffer1 = buffer1[1:100]
                    
            if n % 100 == 0:
                fps = np.mean(buffer1)
                fps = round(fpss)
            
            # rainy warning
            cv2.putText(frame, str(int(flag)) +'%' , (50, 800), cv2.FONT_HERSHEY_TRIPLEX, 5, (158, 213, 11 ), 5, cv2.LINE_AA)         
            
            # Text putting
            cv2.putText(frame,'fps: '+str(fps), (1200, 100), cv2.FONT_HERSHEY_TRIPLEX, 2, (48, 255, 48), 3, cv2.LINE_AA)
            
            cv2.putText(frame, classes[ans1], (30, 100), cv2.FONT_HERSHEY_TRIPLEX, 4 , color[ans1] ,  3, cv2.LINE_AA)      
            
            lux = 500
            luy = 20
            rdx = lux+10
            tn  = 20
            xx = 30
            x  = 7
            
            cv2.rectangle(frame,(lux,luy+0*xx),(rdx+int(t0)*x,luy+0*xx+tn),   (68,240,68),-1)
            cv2.rectangle(frame,(lux,luy+1*xx),(rdx+int(t1)*x,luy+1*xx+tn),   (68,68,255),-1)
            cv2.rectangle(frame,(lux,luy+2*xx),(rdx+int(t2)*x,luy+2*xx+tn),   (255,68,68),-1)
            cv2.rectangle(frame,(lux,luy+3*xx),(rdx+int(t3)*x,luy+3*xx+tn),   (118,32,222)  ,-1)
            
            lll = 1400
            ddd = 640
            y = 4
            
            cv2.rectangle(frame,(lll+0*xx,ddd),(lll+0*xx+tn,ddd-int(d0)*y-10),   (246,40,156)  ,-1)
            cv2.rectangle(frame,(lll+1*xx,ddd),(lll+1*xx+tn,ddd-int(d1)*y-10),   (16,193,234)  ,-1)
            cv2.putText(frame, day[ans2], (1380, 720), cv2.FONT_HERSHEY_TRIPLEX, 3, (226, 226, 226), 5, cv2.LINE_AA)
            

            # Image show
            cv2.imshow('frame',frame)
            cv2.moveWindow("frame", 40,30)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
            cv2.waitKey(20)
            
            # calculate fps
            end = time.time()
            seconds = end - start
            fpss  = 1 / seconds
            buffer1.append(fpss)
        except:
            pass
        n+=1
    cap.release()
    cv2.destroyAllWindows()


test(9)
test(5)

test(2)
test(4)
test(8)
test(4)
test(0)
test(1)
test(7)
test(13)


test(0)
test(8)
test(1)
test(3)





test(6)
#test(10)
#test(11)

#test(12)

test(14)
test(15)
#test(16)
test(17)



#
#import numpy as np
#import cv2
#canvas = np.zeros((300,300,3),dtype="uint8")
#
#green = (0,255,0)
#cv2.line(canvas,(0,150),(300,150),green,2)
#cv2.imshow("Canvas",canvas)
#cv2.waitKey(0)
#cv2.destroyAllWindows()
#








