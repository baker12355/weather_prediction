import numpy as np
import random
import json
import PIL.ImageOps
import os
from keras.preprocessing import image as image_utils

# setting path and classes mapping

label_path='/home/baker/Desktop/BDD100K/bdd100k_label/labels/100k/train'
image_path='/home/baker/Desktop/BDD100K/bdd100k/images/100k/train'

classes = { "clear": 0, "overcast" : 1, "rainy": 2, "snowy":3 }
classes_t = {"daytime": 0 , "night": 1}


files = os.listdir(label_path)
labels=[]
i=0
# load file.json information
for file in files :
    with open( label_path +'/'+ file , 'r') as reader:
        i+=1
        if i%100==0:
            print (i) 
        jf = json.loads(reader.read())
        labels.append(jf)

size=224
classes = { "clear":0, "foggy":1, "overcast":2, "partly cloudy":3,
           "rainy":4, "snowy":5, "undefined":6 }
    
# we convert all image into array so that we can save them into .npy format
counter=0
dest = '/home/baker/Desktop/BDD100K/digitalize/'+str(size)+'/train'

for weather in classes:
    train_data=[]
    train_label=[]
    for label in labels :
        
        counter+=1
        
        if (counter%1000==0):
            print (counter) 

        if label['attributes']['weather']!= weather :
            continue
        
        if label['attributes']['timeofday']=='undefined':
            continue
    
        img = image_utils.load_img(image_path + "/" + label['name']+'.jpg', target_size=(size, size))  # open an image
        #img = PIL.ImageOps.invert(img)  # inverts it
    
        img = image_utils.img_to_array(img)  # converts it to array
    
        
        if label['attributes']['timeofday']!='night':
            train_label.append(0)
        else :
            train_label.append(1)
        
        train_data.append(img)

    np.save(dest +"/"+ weather + "/train_data.npy", np.array(train_data))  # model root to save image models(image)
    np.save(dest +"/"+ weather + "/train_label.npy", np.array(train_label))  # model root to save image models(label)




   
# --------------------------------temp----------------------------------------------

# for visuallize image is ok 
import cv2
from matplotlib import pyplot as plt

size=500
train_data=[]
train_label=[]

counter=0
dest = '/home/baker/Desktop/BDD100K/bdd_digitalize/'+str(size)

for label in labels :
    
    counter+=1

    img = image_utils.load_img(image_path + "/" + label['name']+'.jpg', target_size=(size, size))  # open an image

    if (label['attributes']['weather']=='rainy')  :
        
        img1 = cv2.imread(image_path + "/" + label['name']+'.jpg')
        img1 = cv2.resize(img1,(size,size),interpolation=cv2.INTER_CUBIC)

        cv2.imwrite('/home/baker/Desktop/BDD100K/rainy/'+str(counter)+'.png',img1)
        
#        dpi = 80.0
#        xpixels, ypixels = 800, 800
#        fig = plt.figure(figsize=(ypixels/dpi, xpixels/dpi), dpi=dpi)
#        #print (label['attributes']['weather'])
#        plt.imshow(img)
#        plt.show()

    
    img = PIL.ImageOps.invert(img)  # inverts it
    img = image_utils.img_to_array(img)  # converts it to array
    #print (label['attributes']['weather'])
    


"""
#for analysis data distribution
#----------------------- 
for k in classes:
    count=0
    for i in range(70000):
#        if (labels[i]['attributes']['timeofday']=='dawn/dusk') & (labels[i]['attributes']['weather']==k):
#            count+=1
        if (labels[i]['attributes']['timeofday']=='night') :
            count+=1
    print (count/70000)
"""







size=224
classes = { "clear":0, "foggy":1, "overcast":2, "partly cloudy":3,
           "rainy":4, "snowy":5, "undefined":6 }
    
# we convert all image into array so that we can save them into .npy format
counter=0
dest = '/home/baker/Desktop/BDD100K/digitalize/'+str(size)+'/train'

weather = 'clear'
train_data=[]
train_label=[]
for label in labels :
    
    counter+=1
    
    if (counter%1000==0):
        print (counter) 

    if label['attributes']['weather']!= weather :
        continue
    
    if label['attributes']['timeofday']=='undefined':
        continue

    img = image_utils.load_img(image_path + "/" + label['name']+'.jpg', target_size=(size, size))  # open an image
    #img = PIL.ImageOps.invert(img)  # inverts it

    img = image_utils.img_to_array(img)  # converts it to array

    
    if label['attributes']['timeofday']!='night':
        train_label.append(0)
    else :
        train_label.append(1)
    
    train_data.append(img)
    if len(train_data)==10000:
        break
    
    
np.save(dest +"/"+ weather + "/clear10K_d.npy", np.array(train_data))  # model root to save image models(image)
np.save(dest +"/"+ weather + "/clear10K_l.npy", np.array(train_label))  # model root to save image models(label)




























