import numpy as np
from keras.utils import np_utils
from keras.models import load_model
import tools as T


classes = { "clear":0, "foggy":1, "overcast":2, "partly cloudy":3,
           "rainy":4, "snowy":5, "undefined":6 }

def preprocess_input(x):
    x = np.divide(x, 255.0)
    x = np.subtract(x, 0.5)
    x = np.multiply(x, 2.0)
    return x



def load_train ():
    print ('loading data..')    
    # -----------------load every weather in a balance size -----------------------
    

    size = 224
    dest = '/home/baker/Desktop/BDD100K/digitalize/'+str(size)+'/val'
    
    train_clear       = np.load (dest + "/clear/" + "/train_data.npy" )          # 5000 
    train_clear       = train_clear[:1000]
    train_clear       = preprocess_input(train_clear)
    #train_clear       = train_clear/255.0
    print ('clear load')
    
    train_cloudy      = np.load (dest + "/partly cloudy/"  + "/train_data.npy" ) # 4886
    train_cloudy      = preprocess_input(train_cloudy)
    #train_cloudy      = train_cloudy/255.0
    print ('cloudy load')
    
    train_overcast    = np.load (dest + "/overcast/"     + "/train_data.npy" )   # 8784
    train_overcast    = preprocess_input(train_overcast)
    #train_overcast    = train_overcast/255.0
    print ('overcast load')
    
    train_rainy       = np.load (dest + "/rainy/"      + "/train_data.npy" )     # 5070
    train_rainy       = preprocess_input(train_rainy)
    #train_rainy       = train_rainy/255.0
    print ('rainy load')
    
    t_clear_label     = np.array ([0 for i in range(len(train_clear))])
    t_cloudy_label    = np.array ([1 for i in range(len(train_cloudy))])
    t_overcast_label  = np.array ([2 for i in range(len(train_overcast))])
    t_rainy_label     = np.array ([3 for i in range(len(train_rainy))])
    
    
    # -----------------load labels - day or night ---------------------------------
    
    d_clear_label     = np.load(dest + "/clear/"  + "/train_label.npy" ) 
    d_clear_label     = d_clear_label[:1000]
    d_cloudy_label    = np.load(dest + "/partly cloudy/"  + "/train_label.npy" ) 
    d_overcast_label  = np.load(dest + "/overcast/"   + "/train_label.npy" )    
    d_rainy_label     = np.load(dest + "/rainy/"  + "/train_label.npy" ) 

    
    # -----------------create new labels clear or not -----------------------------
    pass

    # --------------------vertical concat them &  ---------------------------------
    
    train_data    = np.vstack([train_clear,train_cloudy,train_overcast,train_rainy])
    train_label   = np.hstack([t_clear_label,t_cloudy_label,t_overcast_label,t_rainy_label])
    train_label_d = np.hstack([d_clear_label,d_cloudy_label,d_overcast_label,d_rainy_label])
    
    
    print ('done')  
    return train_data,train_label,train_label_d





























