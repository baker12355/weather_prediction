import numpy as np 
from keras.utils import np_utils


classes = { "clear":0, "foggy":1, "overcast":2, "partly cloudy":3,
           "rainy":4, "snowy":5, "undefined":6 }


def preprocess_input(x):
    x = np.divide(x, 255.0)
    x = np.subtract(x, 0.5)
    x = np.multiply(x, 2.0)
    return x


def load_train ():
    print ('loading data..')    
    # ---------------------------------------------------------------------------
    
    num_classes = 3
    num_classes2= 2
    size = 224
    dest = '/home/baker/Desktop/BDD100K/digitalize/'+str(size)+'/train'
    
    # -----------------load labels - day or night -vertical concat them &--------

    d_cloudy_label    = np.load(dest + "/partly cloudy/"  + "/train_label.npy" ) 
    d_overcast_label  = np.load(dest + "/overcast/"   + "/train_label.npy" )    
    d_overcast_label  = d_overcast_label[:5000]
    d_rainy_label     = np.load(dest + "/rainy/"  + "/train_label.npy" ) 
    

    t_cloudy_label    = np.array ([0 for i in range(len(d_cloudy_label))])
    t_overcast_label  = np.array ([1 for i in range(len(d_overcast_label))])
    t_rainy_label     = np.array ([2 for i in range(len(d_rainy_label))])


    train_label   = np.hstack([t_cloudy_label,t_overcast_label,t_rainy_label])
    train_label_d = np.hstack([d_cloudy_label,d_overcast_label,d_rainy_label])
    
    train_label   = np_utils.to_categorical(train_label, num_classes)
    train_label_d = np_utils.to_categorical(train_label_d, num_classes2)
    print ('label done.')
    
    # --------------------load every weather in a balance size------------------
    
    train_cloudy      = np.load (dest + "/partly cloudy/"  + "/train_data.npy" ) # 4886
    train_cloudy       = preprocess_input(train_cloudy)
    #train_cloudy      = train_cloudy/255.0
    print ('cloudy load.')
    
    train_overcast    = np.load (dest + "/overcast/"     + "/train_data.npy" )   # 8784
    train_overcast    = train_overcast[:5000]
    train_overcast    = preprocess_input(train_overcast)
    #train_overcast    = train_overcast/255.0
    print ('overcast load.')
    
    train_rainy       = np.load (dest + "/rainy/"      + "/train_data.npy" )     # 5070
    train_rainy       = preprocess_input(train_rainy)
    #train_rainy       = train_rainy/255.0
    print ('rainy load.')

    train_data    = np.vstack([train_cloudy,train_overcast,train_rainy])
    
    print ('All done.')  
    return train_data,train_label,train_label_d



# --------------------------------load data------------------------------------


train_data , train_label , train_label_d = load_train()


# --------------------------------build model ---------------------------------

from keras.initializers import RandomNormal
from keras.models import Model
from keras.layers.normalization import BatchNormalization
from keras.layers.convolutional import Conv2D
from keras.layers.convolutional import MaxPooling2D
from keras.layers.core import Activation
from keras.layers.core import Dropout
from keras.layers.core import Lambda
from keras.layers.core import Dense
from keras.layers import Flatten
from keras.layers import Input
from keras.callbacks import ModelCheckpoint , EarlyStopping
import tensorflow as tf

class FashionNet:
	@staticmethod
	def build_category_branch(inputs, numCategories,
		finalAct="softmax", chanDim=-1):
		# utilize a lambda layer to convert the 3 channel input to a
		# grayscale representation
		#x = Lambda(lambda c: tf.image.rgb_to_grayscale(c))(inputs)
 
		# CONV => RELU => POOL
		x = Conv2D(128, (3, 3), padding="same",name='W01',
             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(inputs)
		x = Activation("relu",name='W02')(x)
		x = BatchNormalization(axis=chanDim,name='W03')(x)
		x = MaxPooling2D(pool_size=(3, 3),name='W04')(x)
		x = Dropout(0.25,name='W05')(x)
        
       # CONV => RELU) * 2 => POOL
		x = Conv2D(64, (3, 3), padding="same",name='W06',
             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
		x = Activation("relu",name='W07')(x)
		x = BatchNormalization(axis=chanDim,name='W08')(x)
		x = Conv2D(64, (3, 3), padding="same",name='W09',
             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
		x = Activation("relu",name='W10')(x)
		x = BatchNormalization(axis=chanDim,name='W11')(x)
		x = MaxPooling2D(pool_size=(3, 3),name='W12')(x)
		x = Dropout(0.25,name='W13')(x)
        
#       # CONV => RELU) * 2 => POOL
#		x = Conv2D(128, (3, 3), padding="same",name='W14',
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#		x = Activation("relu",name='W15')(x)
#		x = BatchNormalization(axis=chanDim,name='W16')(x)
#		x = Conv2D(128, (3, 3), padding="same",name='W17',
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#		x = Activation("relu",name='W18')(x)
#		x = BatchNormalization(axis=chanDim,name='W19')(x)
#		x = MaxPooling2D(pool_size=(3, 3),name='W20')(x)
#		x = Dropout(0.25,name='W21')(x)
        
		 # (CONV => RELU) * 2 => POOL
		x = Conv2D(64, (3, 3), padding="same",name='W22',
             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
		x = Activation("relu",name='W23')(x)
		x = BatchNormalization(axis=chanDim,name='W24')(x)
		x = Conv2D(64, (3, 3), padding="same",name='W25',
             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
		x = Activation("relu",name='W26')(x)
		x = BatchNormalization(axis=chanDim,name='W27')(x)
		x = MaxPooling2D(pool_size=(3, 3),name='W28')(x)
		x = Dropout(0.25,name='W29')(x)
        
		 # (CONV => RELU) * 2 => POOL
#		x = Conv2D(128, (3, 3), padding="same",name='T22',strides=3,
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#		x = BatchNormalization(axis=chanDim,name='T24')(x)
#		x = Activation("relu",name='T23')(x)
#		x = Conv2D(128, (3, 3), padding="same",name='T25',strides=3,
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#		x = BatchNormalization(axis=chanDim,name='T27')(x)
#		x = Activation("relu",name='T26')(x)
#		x = MaxPooling2D(pool_size=(2, 2),name='T28')(x)
#		x = Dropout(0.25,name='T29')(x)
        
		# define a branch of output layers for the number of different
		# clothing categories (i.e., shirts, jeans, dresses, etc.)
        
		x = Flatten(name='W30')(x)
		x = Dense(256,name='W31')(x)
		x = Dense(100,name='T31')(x)
		x = Activation("relu",name='W32')(x)
		x = BatchNormalization(name='W33')(x)
		x = Dropout(0.5,name='W34')(x)
		x = Dense(numCategories,name='W35')(x)
		x = Activation(finalAct, name="category_output")(x)
 
		# return the category prediction sub-network
		return x

	@staticmethod
	def build_color_branch(inputs, numColors, finalAct="softmax",
		chanDim=-1):
		# CONV => RELU => POOL
		x = Conv2D(16, (3, 3), padding="same")(inputs)
		x = BatchNormalization(axis=chanDim)(x)
		x = Activation("relu")(x)
		x = MaxPooling2D(pool_size=(3, 3))(x)
		x = Dropout(0.25)(x)
 
		# CONV => RELU => POOL
		x = Conv2D(16, (3, 3), padding="same")(x)
		x = BatchNormalization(axis=chanDim)(x)
		x = Activation("relu")(x)
		x = MaxPooling2D(pool_size=(2, 2))(x)
		x = Dropout(0.25)(x)
        
		# CONV => RELU => POOL
		x = Conv2D(32, (3, 3), padding="same")(x)
		x = BatchNormalization(axis=chanDim)(x)
		x = Activation("relu")(x)
		x = MaxPooling2D(pool_size=(2, 2))(x)
		x = Dropout(0.25)(x)
        
		# define a branch of output layers for the number of different
		# colors (i.e., red, black, blue, etc.)
		x = Flatten()(x)
		x = Dense(10)(x)
		x = BatchNormalization()(x)
		x = Activation("relu")(x)
		x = Dropout(0.5)(x)
		x = Dense(numColors)(x)
		x = Activation(finalAct, name="color_output")(x)
 
		# return the color prediction sub-network
		return x
        
        
	@staticmethod
	def build(width, height, numCategories, numColors,
		finalAct="softmax"):
		# initialize the input shape and channel dimension (this code
		# assumes you are using TensorFlow which utilizes channels
		# last ordering)
		inputShape = (height, width, 3)
		chanDim = -1
 
		# construct both the "category" and "color" sub-networks
		inputs = Input(shape=inputShape)
		categoryBranch = FashionNet.build_category_branch(inputs,
			numCategories, finalAct=finalAct, chanDim=chanDim)
		colorBranch = FashionNet.build_color_branch(inputs,
			numColors, finalAct=finalAct, chanDim=chanDim)
 
		# create the model using our input (the batch of images) and
		# two separate outputs -- one for the clothing category
		# branch and another for the color branch, respectively
		model = Model(
			inputs=inputs,
			outputs=[categoryBranch, colorBranch],
			name="fashionnet")
 
		# return the constructed network architecture
		return model


from keras.optimizers import Adam
from sklearn.model_selection import train_test_split

split = train_test_split(train_data, train_label, train_label_d,test_size=0.2, random_state=42)
(trainX, testX, trainWY, testWY,	trainDY, testDY) = split
del train_data,train_label,train_label_d

# initialize our FashionNet multi-output network

EPOCHS = 500
INIT_LR = 1e-2

a = FashionNet()
model = a.build(224 , 224 ,3 , 2 ,finalAct="softmax")
model.summary()

# define two dictionaries: one that specifies the loss method for
# each output of the network along with a second dictionary that
# specifies the weight per loss
losses = {
	"category_output": "categorical_crossentropy",
	"color_output": "categorical_crossentropy",
}
lossWeights = {"category_output": 1.0, "color_output": 0.01}
 
# initialize the optimizer and compile the model
print("[INFO] compiling model...")
opt = Adam(lr=INIT_LR, decay=INIT_LR / EPOCHS)
model.compile(optimizer='adam', loss=losses, loss_weights=lossWeights,
	metrics=["accuracy"])



earlystop = EarlyStopping(monitor='val_loss', min_delta=0, patience=10, verbose=0, mode='auto')

checkpointer = ModelCheckpoint(filepath='modelsCNN/size224/8.1_CNN/dual3_0.h5', verbose=1, save_best_only=True)


H = model.fit(trainX,	{"category_output": trainWY, "color_output": trainDY},
	validation_data=(testX,		{"category_output": testWY, "color_output": testDY}),
    callbacks = [ checkpointer ] ,   
    shuffle=True,
	epochs=EPOCHS,
	verbose=1,
    batch_size=50,
    )




#inputShape = (224, 224, 3)
#chanDim = -1
#numCategories = 4
#
#inputs = Input(shape=inputShape)
#x = Conv2D(128, (2, 2), padding="same",name='W01',
#           kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#           bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(inputs)
#x = BatchNormalization(axis=chanDim,name='W03')(x)
#x = Activation("relu",name='W02')(x)
##x = MaxPooling2D(pool_size=(2, 2),name='W04')(x)
#x = Dropout(0.25,name='W05')(x)
#
## CONV => RELU) * 2 => POOL
#x = Conv2D(64, (3, 3), padding="same",name='W06',
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#x = BatchNormalization(axis=chanDim,name='W08')(x)
#x = Activation("relu",name='W07')(x)
#x = Conv2D(64, (3, 3), padding="same",name='W09',
#           kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#           bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#x = BatchNormalization(axis=chanDim,name='W11')(x)
#x = Activation("relu",name='W10')(x)
#x = MaxPooling2D(pool_size=(4, 4),name='W12')(x)
#x = Dropout(0.25,name='W13')(x)
#
## CONV => RELU) * 2 => POOL
#x = Conv2D(64, (3, 3), padding="same",name='W14',
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#x = Activation("relu",name='W15')(x)
#x = BatchNormalization(axis=chanDim,name='W16')(x)
#x = Conv2D(64, (3, 3), padding="same",name='W17',
#           kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#           bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#x = Activation("relu",name='W18')(x)
#x = BatchNormalization(axis=chanDim,name='W19')(x)
#x = MaxPooling2D(pool_size=(4, 4),name='W20')(x)
#x = Dropout(0.25,name='W21')(x)
#
## define a branch of output layers for the number of different
## clothing categories (i.e., shirts, jeans, dresses, etc.)
#x = Flatten(name='W30')(x)
#x = Dense(100,name='W31')(x)
#x = Dense(50,name='T31')(x)
#x = BatchNormalization(name='W33')(x)
#x = Activation("relu",name='W32')(x)
#x = Dropout(0.5,name='W34')(x)
#x = Dense(numCategories,name='W35')(x)
#x = Activation('softmax', name="category_output")(x)
#
#model = Model(inputs=inputs, outputs= x, name="fashionnet")
#model.summary()
#
#
#
#losses = "categorical_crossentropy"
#
# 
## initialize the optimizer and compile the model
#print("[INFO] compiling model...")
#opt = Adam(lr=INIT_LR, decay=INIT_LR / EPOCHS)
#model.compile(optimizer='adam', loss=losses,metrics=["accuracy"])
#
#
#
#earlystop = EarlyStopping(monitor='val_loss', min_delta=0, patience=10, verbose=0, mode='auto')
#
#checkpointer = ModelCheckpoint(filepath='modelsCNN/size224/8.1_CNN/CNN4_0.h5', verbose=1, save_best_only=True)
#
#
#H = model.fit( trainX, trainWY,
#	validation_data=[testX, testWY],
#    callbacks = [ checkpointer ] ,   
#    shuffle=True,
#	epochs=EPOCHS,
#	verbose=1,
#    batch_size=20,
#    )






