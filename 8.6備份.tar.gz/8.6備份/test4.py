import numpy as np
from keras.utils import np_utils
from keras.models import load_model
import tools as T


classes = { "clear":0, "foggy":1, "overcast":2, "partly cloudy":3,
           "rainy":4, "snowy":5, "undefined":6 }

def preprocess_input(x):
    x = np.divide(x, 255.0)
    x = np.subtract(x, 0.5)
    x = np.multiply(x, 2.0)
    return x



def load_train ():
    print ('loading data..')    
    # -----------------load every weather in a balance size -----------------------
    

    size = 224
    dest = '/home/baker/Desktop/BDD100K/digitalize/'+str(size)+'/val'
    
    train_clear       = np.load (dest + "/clear/" + "/train_data.npy" )          # 5000 
    train_clear       = train_clear[:1000]
    train_clear       = preprocess_input(train_clear)
    #train_clear       = train_clear/255.0
    print ('clear load')
    
    train_cloudy      = np.load (dest + "/partly cloudy/"  + "/train_data.npy" ) # 4886
    train_cloudy      = preprocess_input(train_cloudy)
    #train_cloudy      = train_cloudy/255.0
    print ('cloudy load')
    
    train_overcast    = np.load (dest + "/overcast/"     + "/train_data.npy" )   # 8784
    train_overcast    = preprocess_input(train_overcast)
    #train_overcast    = train_overcast/255.0
    print ('overcast load')
    
    train_rainy       = np.load (dest + "/rainy/"      + "/train_data.npy" )     # 5070
    train_rainy       = preprocess_input(train_rainy)
    #train_rainy       = train_rainy/255.0
    print ('rainy load')
    
    t_clear_label     = np.array ([0 for i in range(len(train_clear))])
    t_cloudy_label    = np.array ([1 for i in range(len(train_cloudy))])
    t_overcast_label  = np.array ([2 for i in range(len(train_overcast))])
    t_rainy_label     = np.array ([3 for i in range(len(train_rainy))])
    
    
    # -----------------load labels - day or night ---------------------------------
    
    d_clear_label     = np.load(dest + "/clear/"  + "/train_label.npy" ) 
    d_clear_label     = d_clear_label[:1000]
    d_cloudy_label    = np.load(dest + "/partly cloudy/"  + "/train_label.npy" ) 
    d_overcast_label  = np.load(dest + "/overcast/"   + "/train_label.npy" )    
    d_rainy_label     = np.load(dest + "/rainy/"  + "/train_label.npy" ) 

    
    # -----------------create new labels clear or not -----------------------------
    pass

    # --------------------vertical concat them &  ---------------------------------
    
    train_data    = np.vstack([train_clear,train_cloudy,train_overcast,train_rainy])
    train_label   = np.hstack([t_clear_label,t_cloudy_label,t_overcast_label,t_rainy_label])
    train_label_d = np.hstack([d_clear_label,d_cloudy_label,d_overcast_label,d_rainy_label])
    
    
    print ('done')  
    return train_data,train_label,train_label_d


# --------------------------------load data------------------------------------

validation_data ,validation_label, validation_label_1 = load_train ()

# -----------------------------------------------------------------------------

classes=['clear','sunny','cloudy','rainy']

def separate_data(v_data, v_label, v_label_1):
    """separates validation data and label according to class no
        Args:
            v_data: validation data to be split
            v_label: validation label to be split
        Returns:
            an array that stores '[val_data,val_label]' in each index for each class.
    """
    vd = [ [ [], [] ] for _ in range(len(classes))]
    for i in range(len(v_data)):
        cls = int(v_label[i])
        vd[cls][0].append(v_data[i])
        vd[cls][1].append(cls)
    for i in range(len(classes)):
        vd[i][0] = np.array(vd[i][0])
        vd[i][1] = np.array(vd[i][1])

    return vd


# each index stores a list which stores validation data and its label according to index no
# vd[0] = [val,lab] for class 0
# vd[1] = [val,lab] for class 1 and so on
vd = separate_data(validation_data, validation_label, validation_label_1)

# number of class
num_classes = 4  # Cloudy,Foggy,Rainy,Snowy,Sunny

# for example if label is 4 converts it [0,0,0,0,1]
validation_label = np_utils.to_categorical(validation_label, num_classes)



# loads trained model and architecture
model = load_model("modelsCNN/size224/8.1_CNN/CNN4_15.h5")
model.summary()



# -------------------------------------------------------
y = model.predict(validation_data, verbose=1 )
y0 = np.argmax(y,axis=1)
#y1 = np.argmax(y[1],axis=1)


acc0 = T.get_accuracy_of_class(T.binary_to_class(validation_label), y0)
#acc1 = T.get_accuracy_of_class(T.binary_to_class(validation_label_1), y1)
print("General Accuracy for Weather Data:", round(acc0,2))
#print("General Accuracy for daytime Data:", round(acc1,2))
print("-----------------------------")


print ('Weather:')
for i in range(len(classes)):
    v_data = vd[i][0]
    v_label = vd[i][1]
    y = model.predict(v_data, verbose=0)
    y = np.argmax(y,axis=1)
    acc = T.get_accuracy_of_class(v_label, y)
    print("Accuracy for class " + classes[i] + ": ", round(acc,2))
    print("-----------------------------")































