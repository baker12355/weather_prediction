import numpy as np
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Flatten, Dropout, Dense
from keras.utils import np_utils
from keras.callbacks import ModelCheckpoint
from keras import regularizers
from keras import backend as K
import tools as T

np.random.seed(0)


train_data = np.load("/home/baker/Desktop/BDD100K/bdd_digitalize/100/7.17/train_data_i.npy")
train_label = np.load("/home/baker/Desktop/BDD100K/bdd_digitalize/100/7.17/train_label_i.npy")


#train_data=train_data[:60000]
#train_label=train_label[:60000]

size = train_data.shape[1]

# normalization
train_data = train_data / 255.0

train_data = train_data.reshape(train_data.shape[0], size, size, 3)

# number of class
num_classes = 7 

# for example if label is 4 converts it [0,0,0,0,1]
train_label = np_utils.to_categorical(train_label, num_classes)


val_data=train_data[60000:]
val_label=train_label[60000:]
train_data=train_data[:60000]
train_label=train_label[:60000]

def mycrossentropy(y_true, y_pred, e=0.1):
    return (1-e)*K.categorical_crossentropy(y_true,y_pred) + e*K.categorical_crossentropy(K.ones_like(y_pred)/num_classes, y_pred)



# -----------------------------------val---------------------------

validation_data = np.load("/home/baker/Desktop/BDD100K/bdd_digitalize/100/7.17/train_data_i.npy")
validation_label = np.load("/home/baker/Desktop/BDD100K/bdd_digitalize/100/7.17/train_label_i.npy")

validation_data=validation_data[60000:]
validation_label=validation_label[60000:]

# normalization
validation_data = validation_data / 255.0

# each index stores a list which stores validation data and its label according to index no
# vd[0] = [val,lab] for class 0
# vd[1] = [val,lab] for class 1 and so on
vd = T.separate_data(validation_data, validation_label)

# number of class
num_classes = 7  # Cloudy,Foggy,Rainy,Snowy,Sunny

# for example if label is 4 converts it [0,0,0,0,1]
validation_label = np_utils.to_categorical(validation_label, num_classes)





# -----------------------------------train -------------------------------------
n=0
def train(layers, conv, k1, k2, epoch):
    global n
    n+=1
    
    filename = str(layers) + '_'+str(conv) + '_'+str(k1) + '_'+str(k2) + '_'+str(epoch)
    
    
    try :
        model = Sequential()
        #convolutional layer with 5x5 32 filters and with relu activation function
        #input_shape: shape of the each data
        #kernel_size: size of the filter
        #strides: default (1,1)
        #activation: activation function such as "relu","sigmoid"
    
        model.add(Conv2D(conv, kernel_size=(k1,k1),input_shape=(size, size, 3), activation='relu'))
        #model.add(MaxPooling2D(pool_size=(2, 2)))
        
        for i in range(layers):
            model.add(Conv2D(conv, kernel_size=(k1,k1), activation='relu'))
            model.add(MaxPooling2D(pool_size=(2, 2)))

        model.add(Conv2D(conv*2, kernel_size=(k2,k2), activation='relu'))
        model.add(MaxPooling2D(pool_size=(2, 2)))
        
        model.add(Flatten())
    
        # beginning of fully connected neural network.
        model.add(Dense(50, activation='relu'))
        model.add(Dense(50, activation='relu'))
        model.add(Dropout(0.5))
        # Add fully connected layer with a softmax activation function
        model.add(Dense(num_classes, activation='softmax'))
        
        # Compile neural network
        model.compile(loss=mycrossentropy, # self_Cross-entropy
                        optimizer='adam', # Root Mean Square Propagation
                        metrics=['accuracy']) # Accuracy performance metric
        
        checkpointer = ModelCheckpoint(filepath='modelsCNN/size100/test/'+filename+'.h5', verbose=0, save_best_only=True)
        
        print ('now training '+str(n) +'th '+filename)
        model.summary()
        
        # begin train the data
        model.fit(train_data, # train data
            train_label, # label
            validation_data=[val_data,val_label],
            epochs= epoch, # Number of epochs
            verbose=0,
            batch_size=256,
            callbacks=[checkpointer]
            )
        y = model.predict_classes(validation_data, verbose=1)
        acc = T.get_accuracy_of_class(T.binary_to_class(validation_label), y)
        print("General Accuracy for Validation Data:", acc)
        print("-----------------------------")
    
    
        for i in range(len(vd)):
            v_data = vd[i][0]
            v_label = vd[i][1]
            y = model.predict_classes(v_data, verbose=0)
            acc = T.get_accuracy_of_class(v_label, y)
            print("Accuracy for class " + T.classes[i] + ": ", acc)
            print("-----------------------------")
    
    except:
        print ('cannot training '+str(n) +'th '+filename)
        pass
    




# (layers, conv, k1, k2, epoch)
    
#0    
#train(1,32,2,1,80)
#train(2,32,2,1,80)
#train(3,32,2,1,80)
#train(4,32,2,1,80)
#train(5,32,2,1,80)
#    
    
# 1 
#train(5,32,1,1,80)
#train(5,32,1,3,80)
#train(5,32,1,5,80)

train(3,32,2,1,40)
train(3,32,2,3,40)
train(3,32,2,5,40)

train(5,32,3,1,80)
train(5,32,3,3,80)
train(5,32,3,5,80)

# 2 
train(5,32,1,1,80)
train(5,32,3,1,80)
train(5,32,5,1,80)

train(5,32,1,2,80)
train(5,32,3,2,80)
train(5,32,5,2,80)

train(5,32,1,3,80)
train(5,32,3,3,80)
train(5,32,5,3,80)

#----------------------------------------------------
# 2.1

train(5,96,2,1,80)
train(5,128,2,1,80)
train(5,256,2,1,80)
train(5,512,2,1,80)