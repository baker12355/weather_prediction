import numpy as np 
from keras.utils import np_utils

classes = { "clear":0, "foggy":1, "overcast":2, "partly cloudy":3,
           "rainy":4, "snowy":5, "undefined":6 }

def preprocess_input(x):
    x = np.divide(x, 255.0)
    x = np.subtract(x, 0.5)
    x = np.multiply(x, 2.0)
    return x

def load_train ():
    print ('loading data..')    
    # ---------------------------------------------------------------------------
    
    num_classes = 4
    num_classes2= 2
    size = 224
    dest = '/home/baker/Desktop/BDD100K/digitalize/'+str(size)+'/train'
    
    # -----------------load labels - day or night -vertical concat them &--------
    
    d_clear_label     = np.load(dest + "/clear/"  + "/clear10K_l.npy" ) 
    d_clear_label     = d_clear_label[:5000]
    d_cloudy_label    = np.load(dest + "/partly cloudy/"  + "/train_label.npy" ) 
    d_overcast_label  = np.load(dest + "/overcast/"   + "/train_label.npy" )    
    d_overcast_label  = d_overcast_label[:5000]
    d_rainy_label     = np.load(dest + "/rainy/"  + "/train_label.npy" ) 
    
    t_clear_label     = np.array ([0 for i in range(len(d_clear_label))])
    t_cloudy_label    = np.array ([1 for i in range(len(d_cloudy_label))])
    t_overcast_label  = np.array ([2 for i in range(len(d_overcast_label))])
    t_rainy_label     = np.array ([3 for i in range(len(d_rainy_label))])


    train_label   = np.hstack([t_clear_label,t_cloudy_label,t_overcast_label,t_rainy_label])
    train_label_d = np.hstack([d_clear_label,d_cloudy_label,d_overcast_label,d_rainy_label])
    
    train_label   = np_utils.to_categorical(train_label, num_classes)
    train_label_d = np_utils.to_categorical(train_label_d, num_classes2)
    print ('label done.')
    
    # --------------------load every weather in a balance size------------------

    train_clear       = np.load (dest + "/clear/" + "/clear10K_d.npy" )          # 5000 
    train_clear       = train_clear[:5000]
    train_clear       = preprocess_input(train_clear)
    #train_clear       = train_clear/255.0
    print ('clear load.')
    
    train_cloudy      = np.load (dest + "/partly cloudy/"  + "/train_data.npy" ) # 4886
    train_cloudy       = preprocess_input(train_cloudy)
    #train_cloudy      = train_cloudy/255.0
    print ('cloudy load.')
    
    train_overcast    = np.load (dest + "/overcast/"     + "/train_data.npy" )   # 8784
    train_overcast    = train_overcast[:5000]
    train_overcast    = preprocess_input(train_overcast)
    #train_overcast    = train_overcast/255.0
    print ('overcast load.')
    
    train_rainy       = np.load (dest + "/rainy/"      + "/train_data.npy" )     # 5070
    train_rainy       = preprocess_input(train_rainy)
    #train_rainy       = train_rainy/255.0
    print ('rainy load.')

    train_data    = np.vstack([train_clear,train_cloudy,train_overcast,train_rainy])
    
    print ('All done.')  
    return train_data,train_label,train_label_d



# --------------------------------load data------------------------------------

train_data , train_label , train_label_d = load_train()

# --------------------------------build model ---------------------------------

from keras.initializers import RandomNormal
from keras.models import Model
from keras.layers.normalization import BatchNormalization
from keras.layers.convolutional import Conv2D
from keras.layers.convolutional import MaxPooling2D
from keras.layers.core import Activation
from keras.layers.core import Dropout
from keras.layers.core import Lambda
from keras.layers.core import Dense
from keras.layers import Flatten
from keras.layers import Input
from keras.callbacks import ModelCheckpoint , EarlyStopping , TensorBoard
import tensorflow as tf

class FashionNet:
	@staticmethod
	def build_category_branch(inputs, numCategories,
		finalAct="softmax", chanDim=-1):
		# utilize a lambda layer to convert the 3 channel input to a
		# grayscale representation
		#x = Lambda(lambda c: tf.image.rgb_to_grayscale(c))(inputs)
 
#		# CONV => RELU => POOL
#		x = Conv2D(32, (3, 3), padding="same",name='W01',
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(inputs)
#		x = BatchNormalization(axis=chanDim,name='W03')(x)
#		x = Activation("relu",name='W02')(x)
#		x = MaxPooling2D(pool_size=(2, 2),name='W04')(x)
#		x = Dropout(0.25,name='W05')(x)
#        
#       # CONV => RELU) * 2 => POOL
#		x = Conv2D(32, (3, 3), padding="same",name='W06',
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#		x = BatchNormalization(axis=chanDim,name='W08')(x)
#		x = Activation("relu",name='W07')(x)
#		x = Conv2D(64, (3, 3), padding="same",name='W09',
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#		x = BatchNormalization(axis=chanDim,name='W11')(x)
#		x = Activation("relu",name='W10')(x)
#		x = MaxPooling2D(pool_size=(2, 2),name='W12')(x)
#		x = Dropout(0.25,name='W13')(x)
#        
#       # CONV => RELU) * 2 => POOL
#		x = Conv2D(64, (3, 3), padding="same",name='W14',
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#		x = Activation("relu",name='W15')(x)
#		x = BatchNormalization(axis=chanDim,name='W16')(x)
#		x = Conv2D(128, (3, 3), padding="same",name='W17',
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#		x = Activation("relu",name='W18')(x)
#		x = BatchNormalization(axis=chanDim,name='W19')(x)
#		x = MaxPooling2D(pool_size=(2, 2),name='W20')(x)
#		x = Dropout(0.25,name='W21')(x)
#        
#		 # (CONV => RELU) * 2 => POOL
#		x = Conv2D(128, (3, 3), padding="same",name='W22',
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#		x = BatchNormalization(axis=chanDim,name='W24')(x)
#		x = Activation("relu",name='W23')(x)
#		x = Conv2D(256, (3, 3), padding="same",name='W25',
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#		x = BatchNormalization(axis=chanDim,name='W27')(x)
#		x = Activation("relu",name='W26')(x)
#		x = MaxPooling2D(pool_size=(2, 2),name='W28')(x)
#		x = Dropout(0.25,name='W29')(x)
#        
#		  #(CONV => RELU) * 2 => POOL
#		x = Conv2D(256, (3, 3), padding="same",name='T22',strides=3,
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#		x = BatchNormalization(axis=chanDim,name='T24')(x)
#		x = Activation("relu",name='T23')(x)
#		x = Conv2D(512, (3, 3), padding="same",name='T25',strides=3,
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#		x = BatchNormalization(axis=chanDim,name='T27')(x)
#		x = Activation("relu",name='T26')(x)
#		x = MaxPooling2D(pool_size=(2, 2),name='T28')(x)
#		x = Dropout(0.25,name='T29')(x)
        
		  #(CONV => RELU) * 2 => POOL
#		x = Conv2D(1024, (3, 3), padding="same",name='S22',strides=3,
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#		x = BatchNormalization(axis=chanDim,name='S24')(x)
#		x = Activation("relu",name='S23')(x)
#		x = Conv2D(1024, (3, 3), padding="same",name='S25',strides=3,
#             kernel_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None),
#             bias_initializer=RandomNormal(mean=0.0, stddev=0.05, seed=None))(x)
#		x = BatchNormalization(axis=chanDim,name='S27')(x)
#		x = Activation("relu",name='S26')(x)
#		#x = MaxPooling2D(pool_size=(2, 2),name='S28')(x)
#		x = Dropout(0.25,name='S29')(x)
        
		# define a branch of output layers for the number of different
		# clothing categories (i.e., shirts, jeans, dresses, etc.)   
        
        
		# CONV => RELU => POOL
		x = Conv2D(32, (3, 3), padding="same",)(inputs)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		x = MaxPooling2D(pool_size=(2, 2),)(x)
		x = Dropout(0.25,)(x)
        
        # CONV => RELU *4 => POOL
		x = Conv2D(48, (3, 3), padding="same",)(x)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		x = Conv2D(48, (3, 3), padding="same",)(x)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		#x = MaxPooling2D(pool_size=(2, 2),)(x)
        
		x = Conv2D(48, (3, 3), padding="same",)(x)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		x = Conv2D(48, (3, 3), padding="same",)(x)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		x = MaxPooling2D(pool_size=(2, 2),)(x)
		x = Dropout(0.25,)(x)
        
        # CONV => RELU *4 => POOL
		x = Conv2D(64, (3, 3), padding="same",)(x)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		x = Conv2D(64, (3, 3), padding="same",)(x)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		#x = MaxPooling2D(pool_size=(2, 2),)(x)
        
		x = Conv2D(64, (3, 3), padding="same",)(x)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		x = Conv2D(64, (3, 3), padding="same",)(x)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		x = MaxPooling2D(pool_size=(2, 2),)(x)
		x = Dropout(0.25,)(x)    

        # CONV => RELU *4 => POOL
		x = Conv2D(80, (3, 3), padding="same",)(x)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		x = Conv2D(80, (3, 3), padding="same",)(x)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		x = MaxPooling2D(pool_size=(2, 2),)(x)
        
		x = Conv2D(128, (3, 3), padding="same",)(x)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		x = Conv2D(128, (3, 3), padding="same",)(x)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		x = MaxPooling2D(pool_size=(2, 2),)(x)
		x = Dropout(0.25,)(x)       
        
        # CONV => RELU *4 => POOL
		x = Conv2D(256, (3, 3), padding="same",)(x)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		x = Conv2D(256, (3, 3), padding="same",)(x)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		x = MaxPooling2D(pool_size=(2, 2),)(x)
        
		x = Conv2D(256, (3, 3), padding="same",)(x)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		x = Conv2D(256, (3, 3), padding="same",)(x)
		x = BatchNormalization(axis=chanDim,)(x)
		x = Activation("relu",)(x)
		x = MaxPooling2D(pool_size=(2, 2),)(x)
		x = Dropout(0.25,)(x) 
        
        # CONV => RELU *4 => POOL
#		x = Conv2D(512, (3, 3), padding="same",)(x)
#		x = BatchNormalization(axis=chanDim,)(x)
#		x = Activation("relu",)(x)
#		x = Conv2D(512, (3, 3), padding="same",)(x)
#		x = BatchNormalization(axis=chanDim,)(x)
#		x = Activation("relu",)(x)
#		#x = MaxPooling2D(pool_size=(2, 2),)(x)
#        
#		x = Conv2D(512, (3, 3), padding="same",)(x)
#		x = BatchNormalization(axis=chanDim,)(x)
#		x = Activation("relu",)(x)
#		x = Conv2D(512, (3, 3), padding="same",)(x)
#		x = BatchNormalization(axis=chanDim,)(x)
#		x = Activation("relu",)(x)
#		x = MaxPooling2D(pool_size=(2, 2),)(x)
#		x = Dropout(0.25,)(x) 
        
		x = Flatten(name='W30')(x)
		x = Dense(256,name='W31')(x)
		x = Dense(100,name='T31')(x)
		x = BatchNormalization(name='W33')(x)
		x = Activation("relu",name='W32')(x)
		x = Dropout(0.5,name='W34')(x)
		x = Dense(numCategories,name='W35')(x)
		x = Activation(finalAct, name="category_output")(x)
 
		# return the category prediction sub-network
		return x

	@staticmethod
	def build_color_branch(inputs, numColors, finalAct="softmax",
		chanDim=-1):
		# CONV => RELU => POOL
		x = Conv2D(16, (3, 3), padding="same")(inputs)
		x = BatchNormalization(axis=chanDim)(x)
		x = Activation("relu")(x)
		x = MaxPooling2D(pool_size=(3, 3))(x)
		x = Dropout(0.25)(x)
 
		# CONV => RELU => POOL
		x = Conv2D(16, (3, 3), padding="same")(x)
		x = BatchNormalization(axis=chanDim)(x)
		x = Activation("relu")(x)
		x = MaxPooling2D(pool_size=(2, 2))(x)
		x = Dropout(0.25)(x)
        
		# CONV => RELU => POOL
		x = Conv2D(32, (3, 3), padding="same")(x)
		x = BatchNormalization(axis=chanDim)(x)
		x = Activation("relu")(x)
		x = MaxPooling2D(pool_size=(2, 2))(x)
		x = Dropout(0.25)(x)
        
		# define a branch of output layers for the number of different
		# colors (i.e., red, black, blue, etc.)
		x = Flatten()(x)
		x = Dense(10)(x)
		x = BatchNormalization()(x)
		x = Activation("relu")(x)
		x = Dropout(0.5)(x)
		x = Dense(numColors)(x)
		x = Activation(finalAct, name="color_output")(x)
 
		# return the color prediction sub-network
		return x
        
        
	@staticmethod
	def build(width, height, numCategories, numColors,
		finalAct="softmax"):
		# initialize the input shape and channel dimension (this code
		# assumes you are using TensorFlow which utilizes channels
		# last ordering)
		inputShape = (height, width, 3)
		chanDim = -1
 
		# construct both the "category" and "color" sub-networks
		inputs = Input(shape=inputShape)
		categoryBranch = FashionNet.build_category_branch(inputs,
			numCategories, finalAct=finalAct, chanDim=chanDim)
		colorBranch = FashionNet.build_color_branch(inputs,
			numColors, finalAct=finalAct, chanDim=chanDim)
 
		# create the model using our input (the batch of images) and
		# two separate outputs -- one for the clothing category
		# branch and another for the color branch, respectively
		model = Model(
			inputs=inputs,
			outputs=[categoryBranch, colorBranch],
			name="fashionnet")
 
		# return the constructed network architecture
		return model


from keras.optimizers import Adam
from sklearn.model_selection import train_test_split

split = train_test_split(train_data, train_label, train_label_d,test_size=0.2, random_state=42)
(trainX, testX, trainWY, testWY,	trainDY, testDY) = split
del train_data,train_label,train_label_d

# initialize our FashionNet multi-output network
batch_size = 50
EPOCHS = 500
INIT_LR = 1e-2

a = FashionNet()
model = a.build(224 , 224 ,4 , 2 ,finalAct="softmax")
model.summary()

# define two dictionaries: one that specifies the loss method for
# each output of the network along with a second dictionary that
# specifies the weight per loss
losses = {
	"category_output": "categorical_crossentropy",
	"color_output": "categorical_crossentropy",
}
lossWeights = {"category_output": 1.0, "color_output": 0.01}
 
# initialize the optimizer and compile the model
print("[INFO] compiling model...")
opt = Adam(lr=INIT_LR, decay=INIT_LR / EPOCHS)
model.compile(optimizer='adam', loss=losses, loss_weights=lossWeights,
	metrics=["accuracy"])



earlystop = EarlyStopping(monitor='val_loss', min_delta=0, patience=10, verbose=0, mode='auto')

checkpointer = ModelCheckpoint(filepath='modelsCNN/size224/8.6_CNN/NORMAL_1.h5', verbose=1, save_best_only=True)

class_weight = {'category_output':{0: 0.3 , 1: 0.4 , 2: 0.4 ,3: 0.5 },
                "color_output":{0 : 0.1 , 1 : 0.2}
                }

from lsuv_init import LSUVinit
model = LSUVinit(model,trainX[:50,:,:,:]) 

H = model.fit(trainX,	{"category_output": trainWY, "color_output": trainDY},
              validation_data=(testX,{"category_output": testWY, "color_output": testDY}),
              callbacks = [checkpointer,earlystop] ,
              shuffle=True,
              epochs=EPOCHS,
              verbose=1,
              batch_size=50,
              class_weight=class_weight)




#from keras.preprocessing.image import ImageDataGenerator
#
#
#earlystop = EarlyStopping(monitor='val_loss', min_delta=0, patience=10, verbose=0, mode='auto')
#checkpointer = ModelCheckpoint(filepath='modelsCNN/size224/8.6_CNN/NORMAL_2.h5', verbose=1, save_best_only=True)
#tbCallBack = TensorBoard(log_dir='./Graph2', histogram_freq=0, write_graph=True, write_images=True)
#
#datagen = ImageDataGenerator(
#    featurewise_center=False,  # set input mean to 0 over the dataset
#    samplewise_center=False,  # set each sample mean to 0
#    featurewise_std_normalization=False,  # divide inputs by std of the dataset
#    samplewise_std_normalization=False,  # divide each input by its std
#    zca_whitening=False,  # apply ZCA whitening
#    rotation_range=10,  # randomly rotate images in the range (degrees, 0 to 180)
#    width_shift_range=0.2,  # randomly shift images horizontally (fraction of total width)
#    height_shift_range=0.2,  # randomly shift images vertically (fraction of total height)
#    horizontal_flip=True,  # randomly flip images
#    vertical_flip=False)  # randomly flip images
#
#datagen.fit(trainX)
#
#
#model.fit_generator(datagen.flow(trainX, batch_size=batch_size),
#                    {"category_output": trainWY , "color_output": trainDY},
#              validation_data=(testX ,{"category_output": testWY, "color_output": testDY}),
#              callbacks = [checkpointer,earlystop,tbCallBack] ,
#              steps_per_epoch = trainX.shape[0] // batch_size,
#              epochs = EPOCHS,)
#
#
#model.fit_generator(datagen.flow(trainX, batch_size=batch_size),
#                    {"category_output": trainWY , "color_output": trainDY},
#                    steps_per_epoch = trainX.shape[0] // batch_size,
#                    epochs=EPOCHS,
#                    validation_data=(testX ,{"category_output": testWY, "color_output": testDY}),
#                    callbacks=[tbCallBack])


# -------------------------- infinite loop -------------------------------------------
classes=['clear','sunny','cloudy','rainy']
day_night=['daytime','night']

from keras.models import load_model
from lsuv_init import LSUVinit
from new_test4 import load_train as lt
from new_test4 import separate_data

validation_data ,validation_label, validation_label_1 = lt()

vd = separate_data(validation_data, validation_label, validation_label_1)

num_classes = 4  

validation_label = np_utils.to_categorical(validation_label, num_classes)



n = 0
while(1):
    n += 1
    model = a.build(224 , 224 ,4 , 2 ,finalAct="softmax")
    losses = {
    	"category_output": "categorical_crossentropy",
    	"color_output": "categorical_crossentropy",}
    
    lossWeights = {"category_output": 1.0, "color_output": 0.01}
    model.compile(optimizer= opt, loss=losses, loss_weights=lossWeights,metrics=["accuracy"])
    earlystop = EarlyStopping(monitor='val_loss', min_delta=0, patience=15, verbose=0, mode='auto')
    checkpointer = ModelCheckpoint(filepath='modelsCNN/size224/8.7_CNN/NORMAL_' + str(n) +'.h5', verbose=1, save_best_only=True)
    
    model = LSUVinit(model,trainX[:25,:,:,:]) 
    H = model.fit(trainX,	{"category_output": trainWY, "color_output": trainDY},
                  validation_data=(testX,{"category_output": testWY, "color_output": testDY}),
                  callbacks = [checkpointer,earlystop] ,
                  shuffle=True,
                  epochs=EPOCHS,
                  verbose=1,
                  batch_size=50,)
                  #class_weight=class_weight)


    # loads trained model and architecture
    model = load_model('modelsCNN/size224/8.7_CNN/NORMAL_'+str(n)+'.h5')
    # -------------------------------------------------------
    y = model.predict(validation_data, verbose=1)
    y0 = np.argmax(y[0],axis=1)
    #y1 = np.argmax(y[1],axis=1)
    acc0 = T.get_accuracy_of_class(T.binary_to_class(validation_label), y0)
    
    with open("modelsCNN/size224/8.7_CNN/NORMAL_"+str(n), "w") as text_file:
        text_file.write("General Accuracy for Weather Data:" + str( round(acc0,2)) + '\n')
        text_file.write("-----------------------------"+ '\n')
        text_file.write ('Weather:'+ '\n')
        for i in range(len(classes)):
            v_data = vd[i][0]
            v_label = vd[i][1]
            y = model.predict(v_data, verbose=0)
            y = np.argmax(y[0],axis=1)
            acc = T.get_accuracy_of_class(v_label, y)
            text_file.write("Accuracy for class " + classes[i] + ": "+ str(round(acc,2))+ '\n')
            text_file.write("-----------------------------"+ '\n')
        text_file.write ('Daytime:'+ '\n')
        for i in range(len(day_night)):
            v_data = vd[i][0]
            v_label = vd[i][2]
            y = model.predict(v_data, verbose=0)
            y = np.argmax(y[1],axis=1)
            acc = T.get_accuracy_of_class(v_label, y)
            text_file.write("Accuracy for class " + day_night[i] + ": "+ str(round(acc,2))+ '\n')
            text_file.write("-----------------------------"+ '\n')








